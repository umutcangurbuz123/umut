import { saveAs } from 'file-saver';
import ExcelJS from 'exceljs';
import { ScanResult, PageScore } from '../types/scan';

export const exportToExcel = async (scanResult: ScanResult) => {
  const workbook = new ExcelJS.Workbook();
  
  // Add a worksheet for summary
  const summarySheet = workbook.addWorksheet('Özet');
  
  // Add headers with styling
  summarySheet.columns = [
    { header: 'Metrik', key: 'metric', width: 30 },
    { header: 'Değer', key: 'value', width: 15 },
  ];
  
  // Style header row
  summarySheet.getRow(1).font = { bold: true };
  summarySheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: '4B6BFB' }
  };
  summarySheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFF' } };
  
  // Add summary data
  summarySheet.addRow({ metric: 'Taranan URL', value: scanResult.url });
  summarySheet.addRow({ metric: 'Tarama Tarihi', value: new Date(scanResult.scanDate).toLocaleString('tr-TR') });
  summarySheet.addRow({ metric: 'Genel Puan', value: `${scanResult.overallScore}%` });
  summarySheet.addRow({ metric: 'Deneyim Puanı', value: `${scanResult.experienceScore}%` });
  summarySheet.addRow({ metric: 'Uzmanlık Puanı', value: `${scanResult.expertiseScore}%` });
  summarySheet.addRow({ metric: 'Yetkinlik Puanı', value: `${scanResult.authoritativenessScore}%` });
  summarySheet.addRow({ metric: 'Güvenilirlik Puanı', value: `${scanResult.trustworthinessScore}%` });
  summarySheet.addRow({ metric: 'Taranan Sayfa Sayısı', value: scanResult.pageScores.length });
  summarySheet.addRow({ metric: 'Kritik Sorun Sayısı', value: scanResult.criticalIssuesCount });
  
  // Add a row for overall summary
  summarySheet.addRow({ metric: 'Genel Değerlendirme', value: '' });
  const summaryRowIndex = 10;
  summarySheet.getCell(`A${summaryRowIndex}`).font = { bold: true };
  summarySheet.getCell(`B${summaryRowIndex}`).value = scanResult.overallSummary;
  summarySheet.getRow(summaryRowIndex).height = 60;
  summarySheet.getCell(`B${summaryRowIndex}`).alignment = { wrapText: true, vertical: 'middle' };
  
  // Add key issues
  summarySheet.addRow({ metric: 'Öne Çıkan Sorunlar', value: '' });
  const issuesStartRow = summaryRowIndex + 1;
  summarySheet.getCell(`A${issuesStartRow}`).font = { bold: true };
  
  scanResult.keyIssues.forEach((issue, index) => {
    summarySheet.addRow({ metric: `Sorun ${index + 1}`, value: issue });
  });
  
  // Add strengths
  const strengthsStartRow = issuesStartRow + scanResult.keyIssues.length;
  summarySheet.addRow({ metric: 'Güçlü Yönler', value: '' });
  summarySheet.getCell(`A${strengthsStartRow + 1}`).font = { bold: true };
  
  scanResult.strengths.forEach((strength, index) => {
    summarySheet.addRow({ metric: `Güçlü Yön ${index + 1}`, value: strength });
  });
  
  // Add a worksheet for page scores
  const pagesSheet = workbook.addWorksheet('Sayfa Puanları');
  
  // Add headers
  pagesSheet.columns = [
    { header: 'URL', key: 'url', width: 50 },
    { header: 'Genel Puan', key: 'score', width: 15 },
    { header: 'Deneyim', key: 'experienceScore', width: 15 },
    { header: 'Uzmanlık', key: 'expertiseScore', width: 15 },
    { header: 'Yetkinlik', key: 'authoritativenessScore', width: 15 },
    { header: 'Güvenilirlik', key: 'trustworthinessScore', width: 15 },
    { header: 'Özet', key: 'summary', width: 50 },
  ];
  
  // Style header row
  pagesSheet.getRow(1).font = { bold: true };
  pagesSheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: '4B6BFB' }
  };
  pagesSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFF' } };
  
  // Add page data
  scanResult.pageScores.forEach((page: PageScore) => {
    pagesSheet.addRow({
      url: page.url,
      score: `${page.score}%`,
      experienceScore: `${page.experienceScore}%`,
      expertiseScore: `${page.expertiseScore}%`,
      authoritativenessScore: `${page.authoritativenessScore}%`,
      trustworthinessScore: `${page.trustworthinessScore}%`,
      summary: page.summary
    });
  });
  
  // Add a worksheet for recommendations
  const recommendationsSheet = workbook.addWorksheet('Öneriler');
  
  // Add headers
  recommendationsSheet.columns = [
    { header: 'Kategori', key: 'category', width: 15 },
    { header: 'Başlık', key: 'title', width: 30 },
    { header: 'Açıklama', key: 'description', width: 50 },
    { header: 'Etki', key: 'impact', width: 15 },
    { header: 'Çaba', key: 'effort', width: 15 },
  ];
  
  // Style header row
  recommendationsSheet.getRow(1).font = { bold: true };
  recommendationsSheet.getRow(1).fill = {
    type: 'pattern',
    pattern: 'solid',
    fgColor: { argb: '4B6BFB' }
  };
  recommendationsSheet.getRow(1).font = { bold: true, color: { argb: 'FFFFFF' } };
  
  // Add recommendation data
  scanResult.recommendations.forEach(rec => {
    recommendationsSheet.addRow({
      category: rec.category,
      title: rec.title,
      description: rec.description,
      impact: rec.impact === 'high' ? 'Yüksek' : rec.impact === 'medium' ? 'Orta' : 'Düşük',
      effort: rec.effort === 'high' ? 'Yüksek' : rec.effort === 'medium' ? 'Orta' : 'Düşük',
    });
  });
  
  // Generate Excel file
  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  
  // Format date for filename
  const date = new Date().toISOString().split('T')[0];
  const domain = new URL(scanResult.url).hostname.replace('www.', '');
  
  // Save file
  saveAs(blob, `EEAT_Analiz_${domain}_${date}.xlsx`);
};