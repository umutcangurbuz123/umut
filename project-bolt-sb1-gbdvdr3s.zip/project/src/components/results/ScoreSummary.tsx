import React from 'react';

interface ScoreSummaryProps {
  title: string;
  score: number;
  description: string;
}

const ScoreSummary: React.FC<ScoreSummaryProps> = ({ title, score, description }) => {
  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-amber-500';
    return 'bg-red-500';
  };

  return (
    <div className="bg-white rounded-lg p-4 shadow-sm">
      <div className="flex justify-between items-center mb-2">
        <h3 className="font-medium text-slate-800">{title}</h3>
        <div className={`text-white text-xs font-bold px-2 py-1 rounded-full ${getScoreColor(score)}`}>
          {score}%
        </div>
      </div>
      <p className="text-xs text-slate-600">{description}</p>
      
      <div className="mt-3 bg-slate-100 rounded-full h-2 overflow-hidden">
        <div 
          className={`h-full rounded-full ${getScoreColor(score)}`} 
          style={{ width: `${score}%` }}
        ></div>
      </div>
    </div>
  );
};

export default ScoreSummary;