import React, { useState } from 'react';
import { ExternalLink, ArrowUpDown, Search } from 'lucide-react';
import { PageScore } from '../../types/scan';

interface PageScoresListProps {
  pageScores: PageScore[];
}

const PageScoresList: React.FC<PageScoresListProps> = ({ pageScores }) => {
  const [sortField, setSortField] = useState<string>('url');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedPage, setExpandedPage] = useState<string | null>(null);

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };

  const getSortedPages = () => {
    const filteredPages = pageScores.filter(page => 
      page.url.toLowerCase().includes(searchQuery.toLowerCase())
    );

    return filteredPages.sort((a, b) => {
      let aValue: any = a[sortField as keyof PageScore];
      let bValue: any = b[sortField as keyof PageScore];
      
      if (sortField === 'url') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (aValue === bValue) return 0;
      
      const result = aValue > bValue ? 1 : -1;
      return sortDirection === 'asc' ? result : -result;
    });
  };

  const sortedPages = getSortedPages();

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-amber-500';
    return 'text-red-600';
  };

  const getScoreBgColor = (score: number): string => {
    if (score >= 80) return 'bg-green-100 border-green-200';
    if (score >= 60) return 'bg-amber-100 border-amber-200';
    return 'bg-red-100 border-red-200';
  };

  const toggleExpand = (url: string) => {
    if (expandedPage === url) {
      setExpandedPage(null);
    } else {
      setExpandedPage(url);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden">
      {/* Search */}
      <div className="p-4 border-b border-slate-200">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search size={18} className="text-slate-400" />
          </div>
          <input
            type="text"
            className="pl-10 pr-4 py-2 w-full border border-slate-300 rounded-md focus:ring-primary-500 focus:border-primary-500"
            placeholder="Sayfa URL'si ile arayın..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </div>
      
      {/* Table */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-slate-200">
          <thead className="bg-slate-50">
            <tr>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('url')}
              >
                <div className="flex items-center">
                  URL
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('score')}
              >
                <div className="flex items-center">
                  Genel Puan
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('experienceScore')}
              >
                <div className="flex items-center">
                  Deneyim
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('expertiseScore')}
              >
                <div className="flex items-center">
                  Uzmanlık
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('authoritativenessScore')}
              >
                <div className="flex items-center">
                  Yetkinlik
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
              <th 
                scope="col" 
                className="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer"
                onClick={() => handleSort('trustworthinessScore')}
              >
                <div className="flex items-center">
                  Güvenilirlik
                  <ArrowUpDown size={14} className="ml-1" />
                </div>
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-slate-200">
            {sortedPages.map((page) => (
              <React.Fragment key={page.url}>
                <tr 
                  className="hover:bg-slate-50 cursor-pointer"
                  onClick={() => toggleExpand(page.url)}
                >
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <div className="flex items-center">
                      <span className="truncate max-w-[200px]">{page.url}</span>
                      <a 
                        href={page.url} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="ml-2 text-primary-600 hover:text-primary-800"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <ExternalLink size={14} />
                      </a>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`font-medium ${getScoreColor(page.score)}`}>
                      {page.score}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`font-medium ${getScoreColor(page.experienceScore)}`}>
                      {page.experienceScore}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`font-medium ${getScoreColor(page.expertiseScore)}`}>
                      {page.expertiseScore}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`font-medium ${getScoreColor(page.authoritativenessScore)}`}>
                      {page.authoritativenessScore}%
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`font-medium ${getScoreColor(page.trustworthinessScore)}`}>
                      {page.trustworthinessScore}%
                    </span>
                  </td>
                </tr>
                
                {expandedPage === page.url && (
                  <tr>
                    <td colSpan={6} className="p-0">
                      <div className="p-4 bg-slate-50 animate-slideUp">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className={`p-4 rounded border ${getScoreBgColor(page.score)}`}>
                            <h4 className="font-medium mb-2">Sayfa Özeti</h4>
                            <p className="text-sm text-slate-700">{page.summary}</p>
                          </div>
                          
                          <div className="space-y-3">
                            <div>
                              <h4 className="font-medium mb-1">Öne Çıkan Sorunlar</h4>
                              <ul className="text-sm">
                                {page.issues.map((issue, idx) => (
                                  <li key={idx} className="mb-1 text-red-600">• {issue}</li>
                                ))}
                              </ul>
                            </div>
                            
                            <div>
                              <h4 className="font-medium mb-1">İyileştirme Önerileri</h4>
                              <ul className="text-sm">
                                {page.recommendations.map((rec, idx) => (
                                  <li key={idx} className="mb-1 text-blue-600">• {rec}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            ))}
            
            {sortedPages.length === 0 && (
              <tr>
                <td colSpan={6} className="px-6 py-4 text-center text-slate-500">
                  Aramanızla eşleşen sayfa bulunamadı.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default PageScoresList;