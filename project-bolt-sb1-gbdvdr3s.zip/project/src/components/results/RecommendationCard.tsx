import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Zap, Clock } from 'lucide-react';

interface RecommendationCardProps {
  category: string;
  title: string;
  description: string;
  impact: 'low' | 'medium' | 'high';
  effort: 'low' | 'medium' | 'high';
  examples: string[];
}

const RecommendationCard: React.FC<RecommendationCardProps> = ({
  category,
  title,
  description,
  impact,
  effort,
  examples
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  const getCategoryColor = (category: string): string => {
    switch (category.toLowerCase()) {
      case 'deneyim':
        return 'bg-primary-100 text-primary-800';
      case 'uzmanlık':
        return 'bg-secondary-100 text-secondary-800';
      case 'yetkinlik':
        return 'bg-amber-100 text-amber-800';
      case 'güvenilirlik':
        return 'bg-accent-100 text-accent-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const getImpactColor = (impact: string): string => {
    switch (impact) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-amber-100 text-amber-800';
      case 'low':
        return 'bg-blue-100 text-blue-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const getEffortColor = (effort: string): string => {
    switch (effort) {
      case 'high':
        return 'bg-red-100 text-red-800';
      case 'medium':
        return 'bg-amber-100 text-amber-800';
      case 'low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-slate-100 text-slate-800';
    }
  };

  const getImpactText = (impact: string): string => {
    switch (impact) {
      case 'high':
        return 'Yüksek';
      case 'medium':
        return 'Orta';
      case 'low':
        return 'Düşük';
      default:
        return '';
    }
  };

  const getEffortText = (effort: string): string => {
    switch (effort) {
      case 'high':
        return 'Yüksek';
      case 'medium':
        return 'Orta';
      case 'low':
        return 'Düşük';
      default:
        return '';
    }
  };

  return (
    <div className="card hover:shadow-lg">
      <div
        className="flex justify-between items-start cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div>
          <span className={`inline-block px-2 py-1 text-xs font-medium rounded mb-3 ${getCategoryColor(category)}`}>
            {category}
          </span>
          <h3 className="text-lg font-semibold mb-2">{title}</h3>
          <p className="text-slate-600 mb-4">{description}</p>
          
          <div className="flex space-x-4">
            <div className="flex items-center">
              <Zap size={16} className="text-slate-400 mr-1" />
              <span className={`text-xs px-2 py-1 rounded ${getImpactColor(impact)}`}>
                Etki: {getImpactText(impact)}
              </span>
            </div>
            <div className="flex items-center">
              <Clock size={16} className="text-slate-400 mr-1" />
              <span className={`text-xs px-2 py-1 rounded ${getEffortColor(effort)}`}>
                Çaba: {getEffortText(effort)}
              </span>
            </div>
          </div>
        </div>
        
        <button
          className="p-2 hover:bg-slate-100 rounded-full transition-colors"
          aria-label={isExpanded ? 'Kapat' : 'Detayları Göster'}
        >
          {isExpanded ? (
            <ChevronUp size={20} className="text-slate-600" />
          ) : (
            <ChevronDown size={20} className="text-slate-600" />
          )}
        </button>
      </div>
      
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-slate-100 animate-slideUp">
          <h4 className="font-medium mb-2">Örnekler ve İpuçları:</h4>
          <ul className="space-y-2 text-slate-700">
            {examples.map((example, idx) => (
              <li key={idx} className="flex items-start">
                <span className="inline-block w-5 h-5 bg-primary-100 text-primary-800 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mr-2">
                  {idx + 1}
                </span>
                <span>{example}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
};

export default RecommendationCard;