import React from 'react';

interface EeatFactorCardProps {
  title: string;
  description: string;
  color: string;
}

const EeatFactorCard: React.FC<EeatFactorCardProps> = ({ title, description, color }) => {
  return (
    <div className="card overflow-hidden">
      <div className={`w-full h-2 ${color} mb-4`}></div>
      <h3 className="text-xl font-semibold mb-3">{title}</h3>
      <p className="text-slate-600">{description}</p>
    </div>
  );
};

export default EeatFactorCard;