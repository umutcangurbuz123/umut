import React, { ReactNode } from 'react';

interface FeatureCardProps {
  icon: ReactNode;
  title: string;
  description: string;
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description }) => {
  return (
    <div className="card group hover:translate-y-[-5px]">
      <div className="flex items-center mb-4">
        <div className="p-3 rounded-full bg-primary-50 group-hover:bg-primary-100 transition-colors">
          {React.cloneElement(icon as React.ReactElement, { 
            size: 24,
            className: "text-primary-600 group-hover:text-primary-700 transition-colors"
          })}
        </div>
      </div>
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <p className="text-slate-600">{description}</p>
    </div>
  );
};

export default FeatureCard;