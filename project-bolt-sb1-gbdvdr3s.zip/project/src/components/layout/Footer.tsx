import React from 'react';
import { Link } from 'react-router-dom';
import { BarChart3, Twitter, Github as GitHub, Linkedin } from 'lucide-react';

const Footer: React.FC = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-800 text-white pt-12 pb-8">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Column */}
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <BarChart3 size={24} className="text-primary-400" />
              <span className="text-xl font-bold">EEAT Analiz</span>
            </Link>
            <p className="text-slate-300 text-sm mb-4">
              Web sitenizi Google EEAT faktörlerine göre analiz edin, SEO performansınızı artırın.
            </p>
            <div className="flex space-x-4">
              <a
                href="https://twitter.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-primary-400 transition-colors"
                aria-label="Twitter"
              >
                <Twitter size={20} />
              </a>
              <a
                href="https://github.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-primary-400 transition-colors"
                aria-label="GitHub"
              >
                <GitHub size={20} />
              </a>
              <a
                href="https://linkedin.com"
                target="_blank"
                rel="noopener noreferrer"
                className="text-slate-400 hover:text-primary-400 transition-colors"
                aria-label="LinkedIn"
              >
                <Linkedin size={20} />
              </a>
            </div>
          </div>

          {/* Site Links */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Site</h3>
            <ul className="space-y-3">
              <li>
                <Link 
                  to="/" 
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Ana Sayfa
                </Link>
              </li>
              <li>
                <Link 
                  to="/results" 
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Sonuçlar
                </Link>
              </li>
              <li>
                <Link 
                  to="/about" 
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Hakkında
                </Link>
              </li>
            </ul>
          </div>

          {/* Resources */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Kaynaklar</h3>
            <ul className="space-y-3">
              <li>
                <a 
                  href="https://developers.google.com/search/docs/fundamentals/eeat"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Google EEAT Rehberi
                </a>
              </li>
              <li>
                <a 
                  href="https://developers.google.com/search/docs"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Google SEO Dokümantasyonu
                </a>
              </li>
              <li>
                <a 
                  href="https://search.google.com/search-console"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Google Search Console
                </a>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div className="col-span-1">
            <h3 className="text-lg font-semibold mb-4">Yasal</h3>
            <ul className="space-y-3">
              <li>
                <Link 
                  to="/privacy" 
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Gizlilik Politikası
                </Link>
              </li>
              <li>
                <Link 
                  to="/terms" 
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  Kullanım Koşulları
                </Link>
              </li>
              <li>
                <Link 
                  to="/contact" 
                  className="text-slate-300 hover:text-primary-400 transition-colors text-sm"
                >
                  İletişim
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-700 mt-12 pt-6 text-sm text-slate-400 flex flex-col md:flex-row justify-between items-center">
          <p>&copy; {currentYear} EEAT Analiz. Tüm hakları saklıdır.</p>
          <p className="mt-2 md:mt-0">
            Bu site Google ile ilişkili değildir.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;