import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, BarChart3 } from 'lucide-react';

const Header: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <BarChart3 
            size={28} 
            className="text-primary-600" 
            strokeWidth={2.5} 
          />
          <span className="text-xl font-bold text-slate-800">EEAT Analiz</span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:block">
          <ul className="flex items-center space-x-8">
            <li>
              <Link 
                to="/" 
                className={`text-sm font-medium transition-colors ${
                  location.pathname === '/' 
                    ? 'text-primary-600' 
                    : 'text-slate-700 hover:text-primary-500'
                }`}
              >
                Ana Sayfa
              </Link>
            </li>
            <li>
              <Link 
                to="/results" 
                className={`text-sm font-medium transition-colors ${
                  location.pathname === '/results' 
                    ? 'text-primary-600' 
                    : 'text-slate-700 hover:text-primary-500'
                }`}
              >
                Sonuçlar
              </Link>
            </li>
            <li>
              <Link 
                to="/about" 
                className={`text-sm font-medium transition-colors ${
                  location.pathname === '/about' 
                    ? 'text-primary-600' 
                    : 'text-slate-700 hover:text-primary-500'
                }`}
              >
                Hakkında
              </Link>
            </li>
            <li>
              <a 
                href="https://github.com/eeat-analiz"
                target="_blank"
                rel="noopener noreferrer"
                className="btn btn-primary"
              >
                Başla
              </a>
            </li>
          </ul>
        </nav>

        {/* Mobile Menu Button */}
        <button
          className="block md:hidden focus:outline-none"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label={isMenuOpen ? 'Menüyü Kapat' : 'Menüyü Aç'}
        >
          {isMenuOpen ? (
            <X size={24} className="text-slate-800" />
          ) : (
            <Menu size={24} className="text-slate-800" />
          )}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-40 bg-white pt-20 animate-fadeIn md:hidden">
          <nav className="container">
            <ul className="flex flex-col space-y-6 py-8">
              <li>
                <Link
                  to="/"
                  className={`text-lg font-medium transition-colors ${
                    location.pathname === '/' 
                      ? 'text-primary-600' 
                      : 'text-slate-700'
                  }`}
                >
                  Ana Sayfa
                </Link>
              </li>
              <li>
                <Link
                  to="/results"
                  className={`text-lg font-medium transition-colors ${
                    location.pathname === '/results' 
                      ? 'text-primary-600' 
                      : 'text-slate-700'
                  }`}
                >
                  Sonuçlar
                </Link>
              </li>
              <li>
                <Link
                  to="/about"
                  className={`text-lg font-medium transition-colors ${
                    location.pathname === '/about' 
                      ? 'text-primary-600' 
                      : 'text-slate-700'
                  }`}
                >
                  Hakkında
                </Link>
              </li>
              <li className="pt-4">
                <a 
                  href="https://github.com/eeat-analiz"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn btn-primary w-full flex justify-center"
                >
                  Başla
                </a>
              </li>
            </ul>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;