import { ScanResult } from '../types/scan';

// This is a mock service that generates random scan data for demo purposes
// In a real application, this would make API calls to a backend service
export const scanMockWebsite = (url: string, isSitemap: boolean): ScanResult => {
  // Generate random scores between 40 and 90
  const generateScore = () => Math.floor(Math.random() * 51) + 40;
  
  const getRandomString = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

  // Generate a list of mock pages
  const generateMockPages = (baseUrl: string, count: number) => {
    const pages = [];
    const pageTypes = ['', 'hakkimizda', 'iletisim', 'hizmetlerimiz', 'blog', 'blog/seo-nedir', 'blog/google-algoritmalari', 'blog/eeat-faktoru'];
    
    for (let i = 0; i < count; i++) {
      const pageType = i < pageTypes.length ? pageTypes[i] : `sayfa-${i}`;
      const pageUrl = `${baseUrl}/${pageType}`.replace(/\/\/$/, '/');
      
      const experienceScore = generateScore();
      const expertiseScore = generateScore();
      const authoritativenessScore = generateScore();
      const trustworthinessScore = generateScore();
      const score = Math.floor((experienceScore + expertiseScore + authoritativenessScore + trustworthinessScore) / 4);
      
      const issueCount = Math.floor(Math.random() * 3) + 1;
      const issues = [];
      
      for (let j = 0; j < issueCount; j++) {
        issues.push(getRandomString([
          'Yazar bilgisi eksik veya yetersiz',
          'İçerik derinliği yeterli değil',
          'Kaynakça ve atıf eksikliği',
          'Güncel olmayan içerik',
          'Teknik SEO sorunları mevcut',
          'SSL sertifikası eksik',
          'Mobil uyumluluk sorunları',
          'Sayfa yüklenme hızı yavaş',
          'Kullanıcı deneyimi sorunları',
          'Gizlilik politikası eksik veya yetersiz'
        ]));
      }
      
      const recommendationCount = Math.floor(Math.random() * 3) + 1;
      const recommendations = [];
      
      for (let j = 0; j < recommendationCount; j++) {
        recommendations.push(getRandomString([
          'Yazar biyografisi ve uzmanlık bilgilerini ekleyin',
          'İçeriği daha detaylı ve kapsamlı hale getirin',
          'Kaynakça ve atıfları iyileştirin',
          'İçeriği güncel tutun ve düzenli olarak güncelleyin',
          'Teknik SEO sorunlarını giderin',
          'SSL sertifikası ekleyin',
          'Mobil uyumluluk sorunlarını giderin',
          'Sayfa yüklenme hızını artırın',
          'Kullanıcı deneyimini iyileştirin',
          'Gizlilik politikası ekleyin veya iyileştirin'
        ]));
      }
      
      pages.push({
        url: pageUrl,
        score,
        experienceScore,
        expertiseScore,
        authoritativenessScore,
        trustworthinessScore,
        summary: getRandomString([
          'Bu sayfa genel olarak iyi performans gösteriyor ancak bazı EEAT faktörleri açısından iyileştirilebilir.',
          'Bu sayfada önemli EEAT eksiklikleri var ve acilen iyileştirilmesi gerekiyor.',
          'Bu sayfa EEAT faktörleri açısından ortalama bir performans gösteriyor.',
          'Bu sayfa EEAT faktörleri açısından iyi bir performans gösteriyor ancak daha da iyileştirilebilir.'
        ]),
        issues: [...new Set(issues)],
        recommendations: [...new Set(recommendations)]
      });
    }
    
    return pages;
  };

  // Generate mock pages
  const pageCount = isSitemap ? Math.floor(Math.random() * 10) + 20 : Math.floor(Math.random() * 5) + 5;
  const pages = generateMockPages(url, pageCount);
  
  // Calculate overall scores
  const calculateAverage = (key: string) => {
    const sum = pages.reduce((acc, page) => acc + (page as any)[key], 0);
    return Math.floor(sum / pages.length);
  };
  
  const experienceScore = calculateAverage('experienceScore');
  const expertiseScore = calculateAverage('expertiseScore');
  const authoritativenessScore = calculateAverage('authoritativenessScore');
  const trustworthinessScore = calculateAverage('trustworthinessScore');
  const overallScore = Math.floor((experienceScore + expertiseScore + authoritativenessScore + trustworthinessScore) / 4);
  
  // Sort pages by score
  const sortedPages = [...pages].sort((a, b) => b.score - a.score);
  const bestPerformingPages = sortedPages.slice(0, 5).map(page => ({ url: page.url, score: page.score }));
  const worstPerformingPages = [...sortedPages].reverse().slice(0, 5).map(page => ({ url: page.url, score: page.score }));
  
  // Generate random issue count
  const criticalIssuesCount = Math.floor(Math.random() * 5) + 3;
  
  // Generate mock recommendations
  const generateMockRecommendations = () => {
    const recommendations = [
      {
        category: 'Deneyim',
        title: 'Yazar Deneyimini Gösterin',
        description: 'İçerik üreten yazarların birinci elden deneyimlerini içeriğe dahil edin ve okuyucuların bu deneyimden faydalanmasını sağlayın.',
        impact: 'high' as const,
        effort: 'medium' as const,
        examples: [
          'Yazarlara ait deneyim ve uzmanlık alanlarını belirten profil sayfaları oluşturun.',
          'İçeriklerde "birinci elden deneyim" ibarelerini ve kişisel anlatımları vurgulayın.',
          'Yazarların sektördeki deneyim sürelerini ve başarılarını belirtin.'
        ]
      },
      {
        category: 'Uzmanlık',
        title: 'İçerik Derinliği ve Kapsamını Artırın',
        description: 'İçerikleriniz konuyu derinlemesine ele almalı ve okuyucuların tüm sorularına cevap verecek kapsamda olmalıdır.',
        impact: 'high' as const,
        effort: 'high' as const,
        examples: [
          'Her makalede en az 1500-2000 kelime kullanarak konuyu detaylı işleyin.',
          'İlgili tüm alt başlıkları kapsayan, kapsamlı içerikler oluşturun.',
          'Teknik terimleri açıklayan glossary bölümleri ekleyin.',
          'Konuyla ilgili en güncel araştırma ve verileri içeriğe dahil edin.'
        ]
      },
      {
        category: 'Yetkinlik',
        title: 'Güvenilir Kaynaklardan Alıntı Yapın',
        description: 'İçeriğinizde güvenilir ve otoriter kaynaklara atıflar yaparak sitenizin yetkinliğini artırın.',
        impact: 'medium' as const,
        effort: 'low' as const,
        examples: [
          'Akademik makaleler, resmi kurumlar ve tanınmış endüstri kaynaklarından alıntılar yapın.',
          'Her iddia ve istatistik için mutlaka kaynak gösterin.',
          'İçeriğin sonunda kapsamlı bir kaynakça bölümü oluşturun.',
          'Alıntı yapılan kaynaklara doğrudan link verin.'
        ]
      },
      {
        category: 'Güvenilirlik',
        title: 'Şeffaflık ve Güven Sinyallerini Artırın',
        description: 'Sitenizin güvenilirliğini artırmak için şeffaflık politikaları ve güven sinyalleri ekleyin.',
        impact: 'high' as const,
        effort: 'low' as const,
        examples: [
          'Detaylı bir "Hakkımızda" sayfası oluşturun ve şirket bilgilerinizi paylaşın.',
          'İletişim bilgilerinizi (adres, telefon, e-posta) açıkça belirtin.',
          'Gizlilik politikası, kullanım şartları ve çerez politikası ekleyin.',
          'Varsa sertifikalar, ödüller ve profesyonel üyelikleri gösterin.'
        ]
      },
      {
        category: 'Güvenilirlik',
        title: 'Kullanıcı Deneyimini İyileştirin',
        description: 'İyi bir kullanıcı deneyimi, sitenizin güvenilirliğini artırır ve kullanıcıların içeriğinize daha fazla değer vermesini sağlar.',
        impact: 'medium' as const,
        effort: 'medium' as const,
        examples: [
          'Sayfa yüklenme hızını optimize edin.',
          'Mobil uyumluluk sorunlarını giderin.',
          'Kolay gezinme ve kullanıcı dostu bir arayüz tasarlayın.',
          'Reklam yoğunluğunu azaltın ve içerik erişimini kolaylaştırın.'
        ]
      },
      {
        category: 'Uzmanlık',
        title: 'İçerik Güncelliğini Sağlayın',
        description: 'İçeriklerinizin güncel olması, uzmanlık faktörü için önemlidir. Eski veya güncel olmayan bilgiler EEAT puanınızı düşürür.',
        impact: 'medium' as const,
        effort: 'medium' as const,
        examples: [
          'Eski içerikleri düzenli olarak güncelleyin ve güncelleme tarihini belirtin.',
          'Değişen bilgiler ve istatistikler için içerikleri revize edin.',
          'Makalelerin başında veya sonunda "Son güncelleme: [tarih]" bilgisini ekleyin.',
          'Güncel olaylar ve trendler hakkında düzenli içerik üretin.'
        ]
      },
      {
        category: 'Yetkinlik',
        title: 'Endüstri Uzmanlarıyla İş Birliği Yapın',
        description: 'Alanında tanınmış uzmanlarla iş birliği yaparak içeriklerinizin yetkinliğini artırın.',
        impact: 'high' as const,
        effort: 'high' as const,
        examples: [
          'Alanında tanınmış uzmanlarla röportajlar yapın.',
          'Konuk yazarlardan içerik alın veya ortak içerik üretin.',
          'Uzman görüşlerini ve alıntılarını içeriğe dahil edin.',
          'Webinarlar, paneller ve canlı yayınlar için uzmanları davet edin.'
        ]
      }
    ];
    
    // Randomly select 5-7 recommendations
    const count = Math.floor(Math.random() * 3) + 5;
    const shuffled = [...recommendations].sort(() => 0.5 - Math.random());
    return shuffled.slice(0, count);
  };
  
  return {
    url,
    scanDate: new Date().toISOString(),
    overallScore,
    experienceScore,
    expertiseScore,
    authoritativenessScore,
    trustworthinessScore,
    overallSummary: `Siteniz ${url} EEAT faktörleri açısından ${
      overallScore >= 80 ? 'çok iyi' : overallScore >= 60 ? 'orta' : 'zayıf'
    } bir performans gösteriyor. ${
      overallScore >= 80 
        ? 'Siteniz Google EEAT kriterlerini büyük ölçüde karşılıyor, ancak daha da iyileştirmek için çalışabilirsiniz.' 
        : overallScore >= 60 
        ? 'Sitenizde bazı önemli EEAT eksiklikleri var ve bu eksiklikleri gidererek sıralamanızı iyileştirebilirsiniz.' 
        : 'Sitenizde ciddi EEAT eksiklikleri var ve acilen iyileştirme yapmanız gerekiyor.'
    }`,
    keyIssues: [
      'Yazar bilgileri ve uzmanlık alanları yeterince belirtilmemiş',
      'İçerik derinliği ve kapsamı yetersiz',
      'Kaynakça ve atıflar eksik veya yetersiz',
      'Hakkımızda ve İletişim sayfaları iyileştirilmeli',
      'Güncel olmayan içerikler mevcut',
      'Mobil uyumluluk sorunları var'
    ],
    strengths: [
      'Site güvenliği için SSL sertifikası kullanılıyor',
      'Sayfa yüklenme hızı iyi',
      'İçerikler düzenli olarak güncelleniyor',
      'Kullanıcı deneyimi iyi',
      'Gizlilik politikası mevcut'
    ],
    pageScores: pages,
    recommendations: generateMockRecommendations(),
    bestPerformingPages,
    worstPerformingPages,
    criticalIssuesCount,
    recommendationsCount: 10
  };
};