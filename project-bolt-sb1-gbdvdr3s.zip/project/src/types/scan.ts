export interface PageScore {
  url: string;
  score: number;
  experienceScore: number;
  expertiseScore: number;
  authoritativenessScore: number;
  trustworthinessScore: number;
  summary: string;
  issues: string[];
  recommendations: string[];
}

interface Recommendation {
  category: string;
  title: string;
  description: string;
  impact: 'low' | 'medium' | 'high';
  effort: 'low' | 'medium' | 'high';
  examples: string[];
}

export interface ScanResult {
  url: string;
  scanDate: string;
  overallScore: number;
  experienceScore: number;
  expertiseScore: number;
  authoritativenessScore: number;
  trustworthinessScore: number;
  overallSummary: string;
  keyIssues: string[];
  strengths: string[];
  pageScores: PageScore[];
  recommendations: Recommendation[];
  bestPerformingPages: { url: string; score: number }[];
  worstPerformingPages: { url: string; score: number }[];
  criticalIssuesCount: number;
  recommendationsCount: number;
}