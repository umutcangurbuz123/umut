import React from 'react';
import { Link } from 'react-router-dom';
import { Home, AlertTriangle } from 'lucide-react';

const NotFoundPage: React.FC = () => {
  return (
    <div className="min-h-[70vh] flex flex-col items-center justify-center py-12">
      <div className="text-center max-w-md px-4">
        <div className="flex justify-center mb-6">
          <div className="p-4 rounded-full bg-primary-50">
            <AlertTriangle size={48} className="text-primary-600" />
          </div>
        </div>
        
        <h1 className="text-4xl font-bold mb-4 text-slate-800">404</h1>
        <h2 className="text-2xl font-semibold mb-6 text-slate-700">Sayfa Bulunamadı</h2>
        
        <p className="text-slate-600 mb-8">
          Aradığınız sayfa mevcut değil veya başka bir adrese taşınmış olabilir.
        </p>
        
        <Link to="/" className="btn btn-primary inline-flex items-center">
          <Home size={18} className="mr-2" />
          Ana Sayfaya Dön
        </Link>
      </div>
    </div>
  );
};

export default NotFoundPage;