import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { DownloadCloud, AlertCircle, CheckCircle, BarChart4, ExternalLink } from 'lucide-react';
import ScoreSummary from '../components/results/ScoreSummary';
import RecommendationCard from '../components/results/RecommendationCard';
import PageScoresList from '../components/results/PageScoresList';
import { exportToExcel } from '../utils/excelExport';
import { scanMockWebsite } from '../services/scanService';
import { ScanResult, PageScore } from '../types/scan';

const ResultsPage: React.FC = () => {
  const navigate = useNavigate();
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [currentTab, setCurrentTab] = useState<'overview' | 'pages' | 'recommendations'>('overview');

  // Check if scan data exists
  useEffect(() => {
    const scanUrl = localStorage.getItem('scanUrl');
    
    if (!scanUrl) {
      // No scan data, redirect to home
      navigate('/');
      return;
    }
    
    const isSitemap = localStorage.getItem('isSitemap') === 'true';
    
    // Fetch scan results
    setLoading(true);
    
    // Mock scan - in a real app, this would be an API call
    setTimeout(() => {
      const results = scanMockWebsite(scanUrl, isSitemap);
      setScanResult(results);
      setLoading(false);
    }, 1000);
  }, [navigate]);

  const handleExportToExcel = () => {
    if (scanResult) {
      exportToExcel(scanResult);
    }
  };

  if (loading) {
    return (
      <div className="container py-16 flex flex-col items-center justify-center min-h-[60vh]">
        <div className="w-16 h-16 border-4 border-primary-200 border-t-primary-600 rounded-full animate-spin mb-6"></div>
        <h2 className="text-2xl font-bold mb-2">Sonuçlar Yükleniyor</h2>
        <p className="text-slate-600">Analiz sonuçları hazırlanıyor, lütfen bekleyin...</p>
      </div>
    );
  }

  if (!scanResult) {
    return (
      <div className="container py-16">
        <div className="bg-red-50 p-6 rounded-lg border border-red-200 mb-8 flex items-start">
          <AlertCircle className="text-red-500 mr-4 mt-1 flex-shrink-0" />
          <div>
            <h2 className="text-xl font-bold text-red-700 mb-2">Sonuç Bulunamadı</h2>
            <p className="text-red-600 mb-4">
              Bu URL için analiz sonucu bulunamadı. Lütfen yeni bir analiz başlatın.
            </p>
            <button
              onClick={() => navigate('/')}
              className="btn btn-primary"
            >
              Ana Sayfaya Dön
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50 min-h-screen pb-16">
      {/* Header with Result Summary */}
      <div className="bg-white border-b border-slate-200 py-6 mb-8">
        <div className="container">
          <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2">Analiz Sonuçları</h1>
              <div className="flex items-center text-slate-600">
                <span className="mr-2">{scanResult.url}</span>
                <a
                  href={scanResult.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-primary-600 hover:text-primary-700"
                >
                  <ExternalLink size={16} />
                </a>
              </div>
            </div>
            
            <div className="mt-4 md:mt-0">
              <button
                onClick={handleExportToExcel}
                className="btn btn-outline flex items-center space-x-2"
              >
                <DownloadCloud size={18} />
                <span>Excel'e Aktar</span>
              </button>
            </div>
          </div>

          {/* Overall Score Summary */}
          <div className="bg-slate-50 p-4 rounded-lg border border-slate-200">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="col-span-1 sm:col-span-2 lg:col-span-1">
                <div className="flex flex-col items-center justify-center h-full p-4 bg-white rounded-lg shadow-sm">
                  <div className={`text-3xl font-bold ${getScoreColor(scanResult.overallScore)}`}>
                    {scanResult.overallScore}%
                  </div>
                  <p className="text-sm text-slate-600 mt-1">Genel Puan</p>
                </div>
              </div>
              
              <div className="lg:col-span-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 h-full">
                  <ScoreSummary 
                    title="Deneyim" 
                    score={scanResult.experienceScore} 
                    description="İçerik üreticisinin konuyla ilgili deneyimi"
                  />
                  <ScoreSummary 
                    title="Uzmanlık" 
                    score={scanResult.expertiseScore} 
                    description="İçerik oluşturucunun veya web sitesinin uzmanlığı"
                  />
                  <ScoreSummary 
                    title="Yetkinlik" 
                    score={scanResult.authoritativenessScore} 
                    description="İçerik kaynağının veya web sitesinin yetkinliği"
                  />
                  <ScoreSummary 
                    title="Güvenilirlik" 
                    score={scanResult.trustworthinessScore} 
                    description="İçeriğin ve web sitesinin güvenilirliği"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs & Main Content */}
      <div className="container">
        {/* Tabs */}
        <div className="flex border-b border-slate-200 mb-6">
          <button
            className={`px-6 py-3 text-sm font-medium ${
              currentTab === 'overview'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-slate-600 hover:text-primary-600'
            }`}
            onClick={() => setCurrentTab('overview')}
          >
            Genel Bakış
          </button>
          <button
            className={`px-6 py-3 text-sm font-medium ${
              currentTab === 'recommendations'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-slate-600 hover:text-primary-600'
            }`}
            onClick={() => setCurrentTab('recommendations')}
          >
            Öneriler
          </button>
          <button
            className={`px-6 py-3 text-sm font-medium ${
              currentTab === 'pages'
                ? 'text-primary-600 border-b-2 border-primary-600'
                : 'text-slate-600 hover:text-primary-600'
            }`}
            onClick={() => setCurrentTab('pages')}
          >
            Sayfalar ({scanResult.pageScores.length})
          </button>
        </div>

        {/* Tab Content */}
        <div className="mb-8">
          {currentTab === 'overview' && (
            <div className="animate-fadeIn">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* Summary Card */}
                <div className="lg:col-span-2">
                  <div className="card mb-8">
                    <h2 className="text-xl font-bold mb-4 flex items-center">
                      <BarChart4 className="mr-2 text-primary-600" size={20} />
                      Genel Değerlendirme
                    </h2>
                    <p className="text-slate-600 mb-4">
                      {scanResult.overallSummary}
                    </p>
                    
                    <h3 className="text-lg font-medium mb-3">Öne Çıkan Sorunlar</h3>
                    <ul className="space-y-2 mb-6">
                      {scanResult.keyIssues.map((issue, idx) => (
                        <li key={idx} className="flex items-start">
                          <AlertCircle className="text-amber-500 mr-2 mt-1 flex-shrink-0" size={16} />
                          <span>{issue}</span>
                        </li>
                      ))}
                    </ul>
                    
                    <h3 className="text-lg font-medium mb-3">Güçlü Yönler</h3>
                    <ul className="space-y-2">
                      {scanResult.strengths.map((strength, idx) => (
                        <li key={idx} className="flex items-start">
                          <CheckCircle className="text-green-500 mr-2 mt-1 flex-shrink-0" size={16} />
                          <span>{strength}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  
                  {/* Quick Stats Cards */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                    <div className="card bg-primary-50 border border-primary-100">
                      <h3 className="text-sm font-medium text-primary-800 mb-2">Taranan Sayfalar</h3>
                      <p className="text-2xl font-bold text-primary-700">{scanResult.pageScores.length}</p>
                    </div>
                    <div className="card bg-secondary-50 border border-secondary-100">
                      <h3 className="text-sm font-medium text-secondary-800 mb-2">Kritik Sorunlar</h3>
                      <p className="text-2xl font-bold text-secondary-700">{scanResult.criticalIssuesCount}</p>
                    </div>
                    <div className="card bg-accent-50 border border-accent-100">
                      <h3 className="text-sm font-medium text-accent-800 mb-2">İyileştirme Önerileri</h3>
                      <p className="text-2xl font-bold text-accent-700">{scanResult.recommendationsCount}</p>
                    </div>
                  </div>
                </div>
                
                {/* Top Pages Card */}
                <div className="col-span-1">
                  <div className="card">
                    <h2 className="text-xl font-bold mb-4">En İyi/En Kötü Sayfalar</h2>
                    
                    <h3 className="text-md font-medium mb-3 text-green-600">En İyi Performans Gösteren</h3>
                    <ul className="space-y-2 mb-6">
                      {scanResult.bestPerformingPages.map((page, idx) => (
                        <li key={idx} className="border-b border-slate-100 pb-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm truncate max-w-[180px]">{page.url.split('/').pop()}</span>
                            <span className={`font-medium ${getScoreColor(page.score)}`}>
                              {page.score}%
                            </span>
                          </div>
                        </li>
                      ))}
                    </ul>
                    
                    <h3 className="text-md font-medium mb-3 text-red-600">İyileştirilmesi Gereken</h3>
                    <ul className="space-y-2">
                      {scanResult.worstPerformingPages.map((page, idx) => (
                        <li key={idx} className="border-b border-slate-100 pb-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm truncate max-w-[180px]">{page.url.split('/').pop()}</span>
                            <span className={`font-medium ${getScoreColor(page.score)}`}>
                              {page.score}%
                            </span>
                          </div>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          )}

          {currentTab === 'recommendations' && (
            <div className="space-y-6 animate-fadeIn">
              <h2 className="text-2xl font-bold mb-6">İyileştirme Önerileri</h2>
              
              {scanResult.recommendations.map((recommendation, idx) => (
                <RecommendationCard 
                  key={idx}
                  category={recommendation.category}
                  title={recommendation.title}
                  description={recommendation.description}
                  impact={recommendation.impact}
                  effort={recommendation.effort}
                  examples={recommendation.examples}
                />
              ))}
            </div>
          )}

          {currentTab === 'pages' && (
            <div className="animate-fadeIn">
              <h2 className="text-2xl font-bold mb-6">Sayfa Analizleri</h2>
              <PageScoresList pageScores={scanResult.pageScores} />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// Helper function to get text color based on score
const getScoreColor = (score: number): string => {
  if (score >= 80) return 'text-green-600';
  if (score >= 60) return 'text-amber-500';
  return 'text-red-600';
};

export default ResultsPage;