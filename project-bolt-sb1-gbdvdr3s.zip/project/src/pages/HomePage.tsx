import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, FileSearch, ArrowRight, Shuffle, Server, CheckCircle2 } from 'lucide-react';
import UrlInputForm from '../components/home/UrlInputForm';
import FeatureCard from '../components/home/FeatureCard';
import EeatFactorCard from '../components/home/EeatFactorCard';

const HomePage: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleSubmit = async (url: string, isSitemap: boolean) => {
    setIsLoading(true);
    
    // Simulate API call with timeout
    setTimeout(() => {
      // In a real app, this would be an actual API call to your backend
      console.log('Scanning URL:', url, 'Is Sitemap:', isSitemap);
      setIsLoading(false);
      
      // Store scan info in localStorage (for demo)
      localStorage.setItem('scanUrl', url);
      localStorage.setItem('isSitemap', String(isSitemap));
      localStorage.setItem('scanDate', new Date().toISOString());
      
      // Navigate to results page
      navigate('/results');
    }, 2000);
  };

  return (
    <div className="flex flex-col min-h-[calc(100vh-80px)]">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary-600 to-primary-800 text-white py-16 md:py-24">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slideUp">
              <h1 className="text-4xl md:text-5xl font-bold mb-6">
                Google EEAT Faktörlerini Analiz Edin
              </h1>
              <p className="text-lg md:text-xl text-primary-100 mb-8">
                Web sitenizi Google'ın Deneyim, Uzmanlık, Yetkinlik ve Güvenilirlik faktörlerine göre analiz edin. SEO performansınızı artırın.
              </p>
              
              <UrlInputForm 
                onSubmit={handleSubmit} 
                isLoading={isLoading} 
              />
            </div>
            
            <div className="hidden lg:flex justify-center">
              <div className="relative w-full max-w-md">
                <div className="bg-white rounded-lg shadow-xl p-6 transform rotate-1">
                  <div className="flex items-center mb-4">
                    <div className="w-3 h-3 bg-red-500 rounded-full mr-2"></div>
                    <div className="w-3 h-3 bg-yellow-500 rounded-full mr-2"></div>
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                  </div>
                  <div className="space-y-3">
                    <div className="h-6 bg-slate-100 rounded w-3/4"></div>
                    <div className="h-4 bg-slate-100 rounded w-full"></div>
                    <div className="h-4 bg-slate-100 rounded w-5/6"></div>
                    <div className="h-4 bg-slate-100 rounded w-4/6"></div>
                    <div className="mt-6 space-y-3">
                      <div className="h-6 bg-primary-100 rounded w-full"></div>
                      <div className="h-6 bg-secondary-100 rounded w-full"></div>
                      <div className="h-6 bg-accent-100 rounded w-full"></div>
                    </div>
                  </div>
                </div>
                <div className="absolute top-6 right-6 transform rotate-3 bg-white rounded-lg shadow-xl p-6 w-48">
                  <div className="space-y-2">
                    <div className="h-3 bg-green-100 rounded w-full"></div>
                    <div className="h-3 bg-green-200 rounded w-5/6"></div>
                    <div className="h-3 bg-amber-100 rounded w-4/6"></div>
                    <div className="h-3 bg-red-100 rounded w-3/6"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">EEAT Analiz Ne Sağlar?</h2>
            <p className="text-slate-600 max-w-3xl mx-auto">
              Kapsamlı analiz ile web sitenizin Google EEAT faktörlerine uygunluğunu değerlendirin ve actionable önerilerle sitenizi iyileştirin.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Search className="text-primary-500" />}
              title="Kapsamlı URL Taraması"
              description="Tek bir URL veya sitemap.xml dosyası üzerinden sitenizin tamamını tarayın."
            />
            <FeatureCard 
              icon={<Shuffle className="text-primary-500" />}
              title="EEAT Faktör Analizi"
              description="Google'ın Deneyim, Uzmanlık, Yetkinlik ve Güvenilirlik faktörlerini değerlendirin."
            />
            <FeatureCard 
              icon={<FileSearch className="text-primary-500" />}
              title="Detaylı Rapor"
              description="Her sayfa için detaylı değerlendirme ve iyileştirme önerileri alın."
            />
            <FeatureCard 
              icon={<Server className="text-primary-500" />}
              title="Veri Tabanlı Öneriler"
              description="Google'ın en güncel algoritmalarına dayalı stratejik öneriler."
            />
            <FeatureCard 
              icon={<CheckCircle2 className="text-primary-500" />}
              title="Faktör Bazlı Puanlama"
              description="Her bir EEAT faktörü için ayrı puan ve sıralamanızı etkileyen faktörleri görün."
            />
            <FeatureCard 
              icon={<ArrowRight className="text-primary-500" />}
              title="Excel Çıktısı"
              description="Tüm analiz verilerinizi Excel formatında dışa aktarın ve raporlayın."
            />
          </div>
        </div>
      </section>

      {/* EEAT Factors Explanation */}
      <section className="py-16 bg-slate-50">
        <div className="container">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Google EEAT Faktörleri Nedir?</h2>
            <p className="text-slate-600 max-w-3xl mx-auto">
              Google, web sitelerini değerlendirirken EEAT faktörlerini göz önünde bulundurur. Bu faktörler, sitenizin kalitesini ve güvenilirliğini belirler.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <EeatFactorCard 
              title="Deneyim (Experience)"
              description="İçerik üreticisinin konuyla ilgili birinci elden deneyimi olup olmadığını değerlendirir. Kullanıcılar gerçek deneyime dayalı içeriği daha değerli bulur."
              color="bg-primary-500"
            />
            <EeatFactorCard 
              title="Uzmanlık (Expertise)"
              description="İçerik oluşturucunun veya web sitesinin konu hakkında ne kadar bilgili ve uzman olduğunu değerlendirir."
              color="bg-secondary-500"
            />
            <EeatFactorCard 
              title="Yetkinlik (Authoritativeness)"
              description="İçerik kaynağının veya web sitesinin alanında ne kadar yetkili olduğunu, başkalarının bu kaynağı referans gösterip göstermediğini değerlendirir."
              color="bg-amber-500"
            />
            <EeatFactorCard 
              title="Güvenilirlik (Trustworthiness)"
              description="İçeriğin ve web sitesinin ne kadar güvenilir, doğru bilgiler içerdiğini ve kullanıcılara değer sağladığını değerlendirir."
              color="bg-accent-500"
            />
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-primary-800 text-white">
        <div className="container text-center">
          <h2 className="text-3xl font-bold mb-6">Web Sitenizi Hemen Analiz Edin</h2>
          <p className="text-lg mb-8 max-w-2xl mx-auto">
            Google EEAT faktörlerine göre sitenizi analiz edin, eksikleri tespit edin ve sitenizi daha üst sıralara taşıyın.
          </p>
          <a 
            href="#scan-url" 
            className="btn bg-white text-primary-800 hover:bg-slate-100 px-8 py-3 text-base"
          >
            Ücretsiz Tarama Yapın
          </a>
        </div>
      </section>
    </div>
  );
};

export default HomePage;