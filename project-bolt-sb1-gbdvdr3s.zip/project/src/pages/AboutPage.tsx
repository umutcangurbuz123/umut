import React from 'react';
import { Award, Shield, BookOpen, Users } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div className="container py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-center">EEAT Analiz Hakkında</h1>
        
        <div className="bg-white rounded-lg shadow-md p-8 mb-10">
          <p className="text-lg text-slate-600 mb-6">
            EEAT Analiz, web sitenizin Google'ın Deneyim, Uzmanlık, Yetkinlik ve Güvenilirlik (Experience, Expertise, Authoritativeness, Trustworthiness) faktörlerine göre değerlendirilmesini sağlayan bir araçtır. Bu faktörler, Google'ın içerik kalitesini değerlendirmede kullandığı temel ölçütlerdir.
          </p>
          
          <p className="text-lg text-slate-600 mb-6">
            Aracımız, web sitenizi veya sitemap.xml dosyanızı analiz ederek, EEAT faktörlerine uygunluğunu değerlendirir ve sitenizin arama sonuçlarında daha üst sıralara çıkması için öneriler sunar.
          </p>
        </div>
        
        {/* EEAT Explained */}
        <h2 className="text-2xl font-bold mb-6">EEAT Faktörleri Nedir?</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          <div className="bg-white rounded-lg shadow-md p-6 flex">
            <div className="mr-4 bg-primary-50 p-3 rounded-full h-fit">
              <BookOpen className="text-primary-600" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Deneyim (Experience)</h3>
              <p className="text-slate-600">
                İçerik üreticisinin konuyla ilgili birinci elden deneyimi olup olmadığını değerlendirir. Gerçek hayat deneyimine dayalı içerikler her zaman daha değerlidir.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 flex">
            <div className="mr-4 bg-secondary-50 p-3 rounded-full h-fit">
              <Award className="text-secondary-600" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Uzmanlık (Expertise)</h3>
              <p className="text-slate-600">
                İçerik oluşturucunun veya web sitesinin konu hakkında ne kadar bilgili ve uzman olduğunu değerlendirir. Özellikle tıp, hukuk gibi YMYL (Your Money Your Life) kategorilerinde çok önemlidir.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 flex">
            <div className="mr-4 bg-amber-50 p-3 rounded-full h-fit">
              <Users className="text-amber-600" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Yetkinlik (Authoritativeness)</h3>
              <p className="text-slate-600">
                İçerik kaynağının veya web sitesinin alanında ne kadar yetkili olduğunu, başkalarının bu kaynağı referans gösterip göstermediğini değerlendirir. Backlink profili, marka tanınırlığı ve sektördeki itibar buna dahildir.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg shadow-md p-6 flex">
            <div className="mr-4 bg-accent-50 p-3 rounded-full h-fit">
              <Shield className="text-accent-600" size={24} />
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">Güvenilirlik (Trustworthiness)</h3>
              <p className="text-slate-600">
                İçeriğin ve web sitesinin ne kadar güvenilir, doğru bilgiler içerdiğini ve kullanıcılara değer sağladığını değerlendirir. SSL sertifikası, gizlilik politikası, iletişim bilgileri ve şeffaflık buna dahildir.
              </p>
            </div>
          </div>
        </div>
        
        {/* Why Important */}
        <div className="bg-primary-50 rounded-lg p-8 border border-primary-100 mb-12">
          <h2 className="text-2xl font-bold mb-4">EEAT Neden Önemli?</h2>
          <p className="text-lg mb-4">
            Google, arama sonuçlarında kullanıcılara en kaliteli ve güvenilir içeriği sunmak ister. EEAT faktörleri, Google'ın bir web sitesinin kalitesini ve güvenilirliğini değerlendirmek için kullandığı önemli ölçütlerdir.
          </p>
          <p className="text-lg mb-4">
            2022 yılında Google, EEAT'e 'Deneyim' faktörünü ekleyerek bu kriterlerin önemini daha da artırdı. Özellikle YMYL (Your Money Your Life) kategorilerinde yer alan siteler için EEAT faktörleri hayati önem taşımaktadır.
          </p>
          <p className="text-lg">
            EEAT faktörlerine uygun bir web sitesi, kullanıcılara daha iyi bir deneyim sunarken, Google sıralamasında da daha üst sıralara çıkma şansına sahip olur.
          </p>
        </div>
        
        {/* How We Analyze */}
        <h2 className="text-2xl font-bold mb-6">Nasıl Analiz Ediyoruz?</h2>
        <div className="bg-white rounded-lg shadow-md p-8 mb-12">
          <p className="text-lg text-slate-600 mb-4">
            EEAT Analiz aracımız, web sitenizi çeşitli faktörlere göre değerlendirir:
          </p>
          
          <ul className="space-y-3 text-slate-600 mb-6">
            <li className="flex items-start">
              <span className="inline-block w-5 h-5 bg-primary-100 text-primary-800 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mr-2">
                1
              </span>
              <span><strong>İçerik Analizi:</strong> Makalelerin uzunluğu, derinliği, özgünlüğü ve kapsamı değerlendirilir.</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-5 h-5 bg-primary-100 text-primary-800 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mr-2">
                2
              </span>
              <span><strong>Yazar Bilgileri:</strong> Yazar biyografilerinin varlığı, uzmanlık alanlarının belirtilmesi ve sosyal medya profilleri kontrol edilir.</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-5 h-5 bg-primary-100 text-primary-800 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mr-2">
                3
              </span>
              <span><strong>Kaynakça ve Atıflar:</strong> İçerikte kullanılan kaynakların kalitesi ve ilgili atıfların doğruluğu değerlendirilir.</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-5 h-5 bg-primary-100 text-primary-800 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mr-2">
                4
              </span>
              <span><strong>Hakkımızda ve İletişim Sayfaları:</strong> Şirket bilgileri, ekip üyeleri ve iletişim bilgilerinin şeffaflığı kontrol edilir.</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-5 h-5 bg-primary-100 text-primary-800 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mr-2">
                5
              </span>
              <span><strong>Teknik Faktörler:</strong> SSL sertifikası, mobil uyumluluk, sayfa hızı ve kullanıcı deneyimi analiz edilir.</span>
            </li>
            <li className="flex items-start">
              <span className="inline-block w-5 h-5 bg-primary-100 text-primary-800 rounded-full flex-shrink-0 flex items-center justify-center text-xs font-bold mr-2">
                6
              </span>
              <span><strong>Güven Sinyalleri:</strong> Gizlilik politikası, şartlar ve koşullar, çerez politikası gibi yasal dokümanların varlığı kontrol edilir.</span>
            </li>
          </ul>
          
          <p className="text-lg text-slate-600">
            Bu faktörlerin her biri puanlanarak, web sitenizin EEAT faktörlerine uygunluğu belirlenir ve sitenizi güçlendirmek için öneriler sunulur.
          </p>
        </div>
        
        {/* FAQ */}
        <h2 className="text-2xl font-bold mb-6">Sıkça Sorulan Sorular</h2>
        <div className="bg-white rounded-lg shadow-md p-8 mb-8">
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">EEAT puanı düşük olması sitenin sıralamasını düşürür mü?</h3>
              <p className="text-slate-600">
                EEAT puanı doğrudan bir sıralama faktörü olmasa da, Google'ın kalite değerlendirmelerinde önemli bir rol oynar. Düşük EEAT, özellikle YMYL kategorilerinde sıralama kaybına yol açabilir.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">EEAT iyileştirmeleri ne kadar sürede sonuç verir?</h3>
              <p className="text-slate-600">
                EEAT iyileştirmeleri, genellikle hemen sonuç vermez. Google'ın değişiklikleri tam olarak değerlendirmesi birkaç hafta ile birkaç ay arasında sürebilir. Sabırlı olmak ve tutarlı iyileştirmeler yapmak önemlidir.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">Küçük bir blog için EEAT faktörleri önemli midir?</h3>
              <p className="text-slate-600">
                Evet, site büyüklüğüne bakılmaksızın EEAT faktörleri tüm siteler için önemlidir. Küçük bir blog, EEAT faktörlerine odaklanarak, daha büyük ve otoriter sitelere karşı rekabet avantajı elde edebilir.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-semibold mb-2">EEAT faktörlerini iyileştirmek için en hızlı yol nedir?</h3>
              <p className="text-slate-600">
                Yazar biyografilerini eklemek, içeriğinizi güncellemek, kaynakça ve atıfları iyileştirmek, "Hakkımızda" ve "İletişim" sayfalarını geliştirmek hızlı sonuç veren stratejilerdir. Ancak uzun vadeli EEAT iyileştirmesi için kapsamlı bir yaklaşım gerekir.
              </p>
            </div>
          </div>
        </div>
        
        {/* CTA */}
        <div className="bg-gradient-to-r from-primary-600 to-primary-800 rounded-lg p-8 text-white text-center">
          <h2 className="text-2xl font-bold mb-4">Sitenizi Hemen Analiz Edin</h2>
          <p className="text-lg mb-6">
            Google EEAT faktörlerine göre web sitenizin performansını değerlendirin ve sıralamanızı iyileştirin.
          </p>
          <a href="/" className="btn bg-white text-primary-800 hover:bg-slate-100 px-8 py-3 text-base inline-block">
            Ücretsiz Tarama Yapın
          </a>
        </div>
      </div>
    </div>
  );
};

export default AboutPage;